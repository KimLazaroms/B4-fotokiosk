<?php

    $action = $_POST['action'];

    if ($action == 'create') {
        $img = $_POST['img'];
        if(empty($img)){
            $errors[] = "Vul een foto-naam in.";
        }
        $date = $_POST['date'];
        if(empty($date)){
            $errors[] = "date is verplicht";
        }

        //1. Verbinding
        require_once '../../../config/conn.php';

        //2. Query
        $query= "INSERT INTO fotos (date, img) VALUES (:date, :img)";
        //3. Prepare
        $statement = $conn->prepare($query);
        //4. Execute
        $statement -> Execute([
        ":date" => $date,
        ":img" => $img,
        ]);
        
        if(isset($errors)){
            // var_dump($errors);
            foreach($errors as $error){
                echo $error . '<br>';
            }
            ?><a href="../../../resources/views/foto's/index.php?">GA TERUG</a><?php
            die();
        }
    }

    if ($action == 'update') {

        $date = $_POST['date'];
        if(empty($date)){
            $errors[] = "date is verplicht";
        }

        $id = $_POST['id'];

        if(isset($errors)){
            // var_dump($errors);
            foreach($errors as $error){
                echo $error . '<br>';
            }
            ?><a href="../../../resources/views/foto's/edit.php?id=<?php echo $id;?>">GA TERUG</a><?php
            die();
        }
    
        require_once '../../../config/conn.php';
    
        $query = "UPDATE fotos SET date = :date WHERE id = :id";
        $statement = $conn->prepare($query);
        $statement->execute([
            ":date" => $date,
            ":id" => $id
        ]);
               
        $msg = "De foto is aangepast";	
        header("location: ../../../resources/views/foto's/index.php?msg=$msg");

    }
    if ($action == 'delete') {
        $id = $_POST['id'];

        //1. Verbinding
        require_once '../../../config/conn.php';
        //2. Query
        $query =  "DELETE FROM fotos WHERE id = :id";

        //3. Prepare
        $statement = $conn->prepare($query);
        //4. Execute
        $statement->execute([
        ":id" => $id,
        ]);
        $msg = "De foto is verwijderd";	
        header("location: ../../../resources/views/foto's/index.php?msg=$msg");

    }
?>
