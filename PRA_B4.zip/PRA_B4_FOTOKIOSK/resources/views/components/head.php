<?php require_once __DIR__.'/../../../config/config.php'; ?>

<meta charset="utf-8">
<meta name="description" content="StoringApp voor technische dienst van DeveloperLand">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="<?php echo $base_url; ?>/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="<?php echo $base_url; ?>/public_html/css/normalize.css">
<link rel="stylesheet" href="<?php echo $base_url; ?>/public_html/css/main.css">
